75.52 Taller de Programaci�n II - 2do Cuatrimestre 2012
Ayudante: Patricia Calvo
Grupo: Still in Beta

Fernando Romera Ferrio	-	88406
Hector Aquino Filho	-	88064
Guido Ygounet		-	88246
Gonzalo Almendro	-	80698
