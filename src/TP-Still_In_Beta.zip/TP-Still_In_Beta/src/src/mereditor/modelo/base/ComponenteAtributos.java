package mereditor.modelo.base;

import java.util.Collection;

import mereditor.modelo.Atributo;

public interface ComponenteAtributos {
	Collection<Atributo> getAtributos();
}
