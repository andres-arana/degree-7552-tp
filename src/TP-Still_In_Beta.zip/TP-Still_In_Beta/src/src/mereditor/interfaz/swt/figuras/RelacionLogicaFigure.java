package mereditor.interfaz.swt.figuras;

import mreleditor.modelo.Relacion;


public class RelacionLogicaFigure extends Figura<Relacion> {

	public RelacionLogicaFigure(Relacion componente) {
		super(componente);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void actualizar() {
		// TODO Auto-generated method stub
		
	}

}
